<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            // Primary Key that is also a Foreign Key to users.id
            $table->unsignedInteger('id')->primary();
            $table->foreign('id')->references('id')->on('users')->onDelete('cascade');
            
            // Student-specific attributes
            $table->string('name');
            $table->text('biodata')->nullable();
            $table->enum('current_level', ['beginner', 'intermediate', 'advanced'])->default('beginner');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('students');
    }
};
